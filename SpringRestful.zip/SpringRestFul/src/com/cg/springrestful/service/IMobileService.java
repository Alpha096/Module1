package com.cg.springrestful.service;

import java.util.List;

import org.springframework.stereotype.Service;
import com.cg.springrestful.dto.Mobile;

public interface IMobileService {
	public List<Mobile> getAllData();
}
